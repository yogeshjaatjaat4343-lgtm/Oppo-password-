import React, { useState, useEffect, useRef, useCallback } from 'react';
import { OppoExactHomeScreen } from './components/OppoExactHomeScreen';

interface SavedHistoryEntry {
  id: string;
  pin: string;
  timestamp: string;
  formattedTime: string;
}

export default function App() {
  const [pin, setPin] = useState<string>('');
  const [activeKey, setActiveKey] = useState<string | null>(null);
  const [isUnlocked, setIsUnlocked] = useState<boolean>(false);
  const [customImage, setCustomImage] = useState<string>(() => {
    try {
      return localStorage.getItem('oppo_a53_exact_screenshot') || '';
    } catch {
      return '';
    }
  });

  const [history, setHistory] = useState<SavedHistoryEntry[]>(() => {
    try {
      const stored = localStorage.getItem('oppo_a53_pin_history');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });
  const [showHistoryModal, setShowHistoryModal] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Live time in lock screen status bar
  const [liveTime, setLiveTime] = useState<string>('18:58');
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const h = String(now.getHours()).padStart(2, '0');
      const m = String(now.getMinutes()).padStart(2, '0');
      setLiveTime(`${h}:${m}`);
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // Save screenshot image permanently in localStorage
  const handleSaveScreenshot = useCallback((dataUrl: string) => {
    setCustomImage(dataUrl);
    try {
      localStorage.setItem('oppo_a53_exact_screenshot', dataUrl);
    } catch (err) {
      console.error('LocalStorage write error', err);
    }
  }, []);

  // Handle image upload from file picker
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          handleSaveScreenshot(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Support pasting image anywhere (Ctrl+V / Command+V)
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          const file = items[i].getAsFile();
          if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
              if (typeof event.target?.result === 'string') {
                handleSaveScreenshot(event.target.result);
              }
            };
            reader.readAsDataURL(file);
            break;
          }
        }
      }
    };
    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [handleSaveScreenshot]);

  // Support drag-and-drop on entire screen
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          handleSaveScreenshot(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Save entered PIN to history
  const recordHistory = useCallback((enteredPin: string) => {
    const now = new Date();
    const entry: SavedHistoryEntry = {
      id: `${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      pin: enteredPin,
      timestamp: now.toISOString(),
      formattedTime: now.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      }),
    };

    setHistory((prev) => {
      const updated = [entry, ...prev].slice(0, 100);
      try {
        localStorage.setItem('oppo_a53_pin_history', JSON.stringify(updated));
      } catch {
        // ignore quota
      }
      return updated;
    });
  }, []);

  // Haptic feedback
  const handleKeyFeedback = useCallback(() => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(50);
    }
  }, []);

  // Handle digit press:
  // "password ko pura type to hone do agar kuchh bhi 6 numbers ka password enter karne par hi home screen ka screenshot aaye"
  const handleDigit = useCallback(
    (digit: string) => {
      if (isUnlocked) return;
      if (pin.length >= 6) return; // Prevent typing more than 6

      handleKeyFeedback();
      setActiveKey(digit);
      setTimeout(() => setActiveKey(null), 120);

      const nextPin = pin + digit;
      setPin(nextPin);

      // ONLY after all 6 digits are typed, open the home screen!
      if (nextPin.length === 6) {
        recordHistory(nextPin);
        setTimeout(() => {
          setIsUnlocked(true);
        }, 150); // Small pause so user sees 6th dot fill in black
      }
    },
    [pin, isUnlocked, handleKeyFeedback, recordHistory]
  );

  // Handle backspace
  const handleDelete = useCallback(() => {
    if (isUnlocked) return;
    handleKeyFeedback();
    setActiveKey('delete');
    setTimeout(() => setActiveKey(null), 120);
    setPin((prev) => prev.slice(0, -1));
  }, [isUnlocked, handleKeyFeedback]);

  // Handle hardware keyboard typing
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (showHistoryModal) return;
      if (/^[0-9]$/.test(e.key)) {
        e.preventDefault();
        handleDigit(e.key);
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleDelete();
      } else if (e.key === 'Escape') {
        setPin('');
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleDigit, handleDelete, showHistoryModal]);

  // Re-lock phone
  const handleLockAgain = () => {
    setIsUnlocked(false);
    setPin('');
  };

  return (
    <div
      id="root-container"
      onDragOver={(e) => e.preventDefault()}
      onDrop={handleDrop}
      className="min-h-screen w-full bg-[#111827] flex flex-col items-center justify-center select-none overflow-x-hidden font-sans p-0 sm:p-3"
    >
      {/* Hidden file picker input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Mobile viewport matching Oppo A53 proportions */}
      <div
        id="oppo-mobile-viewport"
        className="relative w-full max-w-[420px] h-[100dvh] sm:h-[880px] sm:max-h-[96vh] bg-white flex flex-col justify-between overflow-hidden sm:rounded-[36px] shadow-2xl text-[#1a1a1a]"
      >
        {/* ================================================================= */}
        {/* UNLOCKED STATE: DIRECT SCREENSHOT DISPLAY                         */}
        {/* ================================================================= */}
        {isUnlocked && (
          <div
            id="oppo-unlocked-home-screen"
            className="absolute inset-0 z-50 w-full h-full bg-black flex flex-col justify-between overflow-hidden animate-in fade-in duration-100"
          >
            <OppoExactHomeScreen
              onLock={handleLockAgain}
              unlockedPin={pin}
              customImage={customImage}
              onSelectImage={handleSaveScreenshot}
            />
          </div>
        )}

        {/* ================================================================= */}
        {/* NATIVE LIGHT MODE LOCK SCREEN (OPPO A53)                          */}
        {/* ================================================================= */}

        {/* 1. Status Bar */}
        <div
          id="system-status-bar"
          className="w-full pt-2.5 px-4 sm:px-5 flex items-center justify-between text-[#111827] text-xs font-medium select-none z-20"
        >
          {/* Left: Punch-hole cutout + Clock 18:58 */}
          <div className="flex items-center gap-2">
            <div
              id="punch-hole-cutout"
              className="w-3.5 h-3.5 rounded-full bg-black flex items-center justify-center shrink-0 -ml-0.5"
            >
              <div className="w-1.5 h-1.5 rounded-full bg-neutral-900 border border-neutral-700"></div>
            </div>

            <span
              className="font-medium text-[13px] tracking-tight ml-0.5 cursor-pointer"
              title="Click to view saved history"
              onClick={() => setShowHistoryModal(true)}
            >
              {liveTime}
            </span>

            <div className="w-3 h-3 flex items-center justify-center opacity-70 ml-0.5">
              <svg viewBox="0 0 24 24" className="w-2.5 h-2.5 fill-current">
                <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z" />
              </svg>
            </div>
          </div>

          {/* Right: VoLTE, Signal, Wi-Fi, Battery 84% */}
          <div className="flex items-center gap-1.5 text-[#111827]">
            <span className="text-[10px] font-semibold border border-current px-0.5 py-0 rounded-xs scale-85 opacity-80">
              VoLTE
            </span>

            <div className="flex items-end gap-0.5 h-2.5">
              <span className="w-0.5 h-1 bg-current rounded-xs"></span>
              <span className="w-0.5 h-1.5 bg-current rounded-xs"></span>
              <span className="w-0.5 h-2 bg-current rounded-xs"></span>
              <span className="w-0.5 h-2.5 bg-current rounded-xs"></span>
            </div>

            <svg
              className="w-3.5 h-3.5 stroke-current stroke-[2.2] fill-none"
              viewBox="0 0 24 24"
            >
              <path d="M5 12.55a11 11 0 0 1 14.08 0" strokeLinecap="round" />
              <path d="M1.42 9a16 16 0 0 1 21.16 0" strokeLinecap="round" />
              <path d="M8.53 16.11a6 6 0 0 1 6.95 0" strokeLinecap="round" />
              <line x1="12" y1="20" x2="12.01" y2="20" strokeLinecap="round" />
            </svg>

            <div className="flex items-center gap-1">
              <span className="text-[11px] font-sans font-medium">84%</span>
              <div className="relative w-4.5 h-2.5 rounded-xs border border-current p-0.5 flex items-center">
                <div className="h-full w-[84%] bg-current rounded-xs"></div>
                <span className="absolute -right-0.5 top-0.5 bottom-0.5 w-0.5 bg-current rounded-r-xs"></span>
              </div>
            </div>
          </div>
        </div>

        {/* 2. Top Action Bar */}
        <div className="w-full px-5 pt-3 pb-1 flex items-center justify-between">
          {/* Back Arrow (Replaced Cross) */}
          <button
            type="button"
            id="btn-back-lock-screen"
            onClick={() => setPin('')}
            aria-label="Back"
            className="w-8 h-8 -ml-1 flex items-center justify-center text-[#1a1a1a] hover:opacity-70 active:scale-90 transition-transform"
          >
            <svg
              className="w-5 h-5 stroke-current stroke-[2.2]"
              viewBox="0 0 24 24"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="19" y1="12" x2="5" y2="12"></line>
              <polyline points="12 19 5 12 12 5"></polyline>
            </svg>
          </button>

          <div className="flex items-center gap-1.5">
            {/* Small Upload Icon */}
            <button
              type="button"
              id="btn-upload-screenshot"
              onClick={() => fileInputRef.current?.click()}
              className="w-8 h-8 rounded-full flex items-center justify-center text-neutral-500 hover:text-neutral-900 active:bg-neutral-100 active:scale-90 transition-all"
              title="स्क्रीनशॉट अपलोड करें"
              aria-label="Upload"
            >
              <svg
                className="w-4.5 h-4.5 stroke-current stroke-[2]"
                viewBox="0 0 24 24"
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="17 8 12 3 7 8" />
                <line x1="12" y1="3" x2="12" y2="15" />
              </svg>
            </button>

            {/* Small History Icon */}
            <button
              type="button"
              id="btn-open-history"
              onClick={() => setShowHistoryModal(true)}
              className="w-8 h-8 rounded-full flex items-center justify-center text-neutral-500 hover:text-neutral-900 active:bg-neutral-100 active:scale-90 transition-all"
              title="पासवर्ड हिस्ट्री देखें"
              aria-label="History"
            >
              <svg
                className="w-4.5 h-4.5 stroke-current stroke-[2]"
                viewBox="0 0 24 24"
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
              </svg>
            </button>
          </div>
        </div>

        {/* 3. Title */}
        <div className="w-full text-center px-6 mt-4">
          <h1 className="text-[19px] font-normal tracking-tight text-[#1a1a1a]">
            पासवर्ड दर्ज करें
          </h1>

          {/* 4. 6-Dot PIN Placeholders: Fill one by one as digits are typed! */}
          <div
            id="pin-placeholders"
            className="flex items-center justify-center gap-3.5 mt-9 mb-4"
          >
            {Array.from({ length: 6 }).map((_, idx) => {
              const isFilled = idx < pin.length;
              return (
                <div
                  key={`dot-${idx}`}
                  className={`w-2.5 h-2.5 rounded-full transition-all duration-100 ease-out ${
                    isFilled
                      ? 'bg-black scale-105' // Black circle when filled
                      : 'bg-[#cfd3d8] scale-100' // Precise soft gray circle when empty
                  }`}
                />
              );
            })}
          </div>
        </div>

        {/* Spacer */}
        <div className="flex-1"></div>

        {/* 5. Keypad */}
        <div className="w-full max-w-[340px] mx-auto px-4 pb-4">
          <div className="grid grid-cols-3 gap-y-3 sm:gap-y-4 place-items-center">
            {/* Row 1 */}
            {['1', '2', '3'].map((num) => (
              <button
                key={num}
                type="button"
                id={`key-${num}`}
                onPointerDown={() => handleDigit(num)}
                className={`w-18 h-18 sm:w-20 sm:h-20 rounded-full flex items-center justify-center transition-all duration-75 select-none ${
                  activeKey === num
                    ? 'bg-[#e5e7eb] scale-95 opacity-80'
                    : 'bg-transparent active:bg-[#e5e7eb]'
                }`}
              >
                <span className="text-[34px] sm:text-[38px] font-normal font-sans text-[#1a1a1a] leading-none">
                  {num}
                </span>
              </button>
            ))}

            {/* Row 2 */}
            {['4', '5', '6'].map((num) => (
              <button
                key={num}
                type="button"
                id={`key-${num}`}
                onPointerDown={() => handleDigit(num)}
                className={`w-18 h-18 sm:w-20 sm:h-20 rounded-full flex items-center justify-center transition-all duration-75 select-none ${
                  activeKey === num
                    ? 'bg-[#e5e7eb] scale-95 opacity-80'
                    : 'bg-transparent active:bg-[#e5e7eb]'
                }`}
              >
                <span className="text-[34px] sm:text-[38px] font-normal font-sans text-[#1a1a1a] leading-none">
                  {num}
                </span>
              </button>
            ))}

            {/* Row 3 */}
            {['7', '8', '9'].map((num) => (
              <button
                key={num}
                type="button"
                id={`key-${num}`}
                onPointerDown={() => handleDigit(num)}
                className={`w-18 h-18 sm:w-20 sm:h-20 rounded-full flex items-center justify-center transition-all duration-75 select-none ${
                  activeKey === num
                    ? 'bg-[#e5e7eb] scale-95 opacity-80'
                    : 'bg-transparent active:bg-[#e5e7eb]'
                }`}
              >
                <span className="text-[34px] sm:text-[38px] font-normal font-sans text-[#1a1a1a] leading-none">
                  {num}
                </span>
              </button>
            ))}

            {/* Row 4 */}
            <div className="w-18 h-18 sm:w-20 sm:h-20"></div>

            <button
              type="button"
              id="key-0"
              onPointerDown={() => handleDigit('0')}
              className={`w-18 h-18 sm:w-20 sm:h-20 rounded-full flex items-center justify-center transition-all duration-75 select-none ${
                activeKey === '0'
                  ? 'bg-[#e5e7eb] scale-95 opacity-80'
                  : 'bg-transparent active:bg-[#e5e7eb]'
              }`}
            >
              <span className="text-[34px] sm:text-[38px] font-normal font-sans text-[#1a1a1a] leading-none">
                0
              </span>
            </button>

            {/* Backspace Button */}
            <button
              type="button"
              id="key-backspace"
              aria-label="Delete"
              onPointerDown={handleDelete}
              className={`w-18 h-18 sm:w-20 sm:h-20 rounded-full flex items-center justify-center transition-all duration-75 select-none ${
                activeKey === 'delete'
                  ? 'bg-[#e5e7eb] scale-95 opacity-80'
                  : 'bg-transparent active:bg-[#e5e7eb]'
              }`}
            >
              <svg
                className="w-7 h-7 sm:w-8 sm:h-8 text-[#1a1a1a] fill-current"
                viewBox="0 0 24 24"
              >
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M22 6H8.5c-.7 0-1.37.31-1.82.85L1.5 12l5.18 5.15c.45.54 1.12.85 1.82.85H22c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-3.71 8.29a.996.996 0 11-1.41 1.41L14.5 13.32l-2.38 2.38a.996.996 0 11-1.41-1.41l2.38-2.38-2.38-2.38a.996.996 0 011.41-1.41l2.38 2.38 2.38-2.38a.996.996 0 011.41 1.41L15.91 11.9l2.38 2.39z"
                />
              </svg>
            </button>
          </div>
        </div>

        {/* 6. Android ColorOS 3-Button Navigation Bar */}
        <div
          id="native-navigation-bar"
          className="w-full h-12 flex items-center justify-around px-8 select-none text-[#555555] pb-1"
        >
          <button
            type="button"
            id="nav-recents"
            onClick={() => setShowHistoryModal(true)}
            className="p-3 active:opacity-60 transition-opacity"
            aria-label="Recent apps / History"
          >
            <div className="flex items-center gap-1">
              <span className="w-0.5 h-3.5 bg-current rounded-full"></span>
              <span className="w-0.5 h-3.5 bg-current rounded-full"></span>
              <span className="w-0.5 h-3.5 bg-current rounded-full"></span>
            </div>
          </button>

          <button
            type="button"
            id="nav-home"
            onClick={() => setPin('')}
            className="p-3 active:opacity-60 transition-opacity"
            aria-label="Home"
          >
            <div className="w-3.5 h-3.5 rounded-xs border-[1.75px] border-current"></div>
          </button>

          <button
            type="button"
            id="nav-back"
            onClick={() => {
              if (pin.length > 0) handleDelete();
            }}
            className="p-3 active:opacity-60 transition-opacity"
            aria-label="Back"
          >
            <svg
              className="w-3.5 h-3.5 stroke-current stroke-[2.5] fill-none"
              viewBox="0 0 24 24"
            >
              <polyline points="15 18 9 12 15 6"></polyline>
            </svg>
          </button>
        </div>
      </div>

      {/* History Modal */}
      {showHistoryModal && (
        <div
          id="history-modal-overlay"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setShowHistoryModal(false)}
        >
          <div
            id="history-modal-content"
            className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl text-[#1a1a1a] flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
              <div>
                <h2 className="text-base font-bold">Password Entry History</h2>
                <p className="text-xs text-neutral-500">हर 6-अंकों का पासवर्ड यहाँ सेव होता है</p>
              </div>
              <button
                type="button"
                onClick={() => setShowHistoryModal(false)}
                className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-sm"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-3 space-y-2">
              {history.length === 0 ? (
                <div className="text-center py-10 text-neutral-400 text-xs">
                  अभी तक कोई पासवर्ड दर्ज नहीं हुआ है। कीपैड पर 6 अंक दबाएँ।
                </div>
              ) : (
                history.map((item, idx) => (
                  <div
                    key={item.id || idx}
                    className="p-2.5 rounded-xl bg-neutral-50 border border-neutral-100 flex items-center justify-between"
                  >
                    <div>
                      <span className="text-base font-mono font-bold tracking-widest text-neutral-900">
                        {item.pin}
                      </span>
                      <p className="text-[10px] text-neutral-400">{item.formattedTime}</p>
                    </div>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      Saved (6 Digits)
                    </span>
                  </div>
                ))
              )}
            </div>

            <div className="pt-3 border-t border-neutral-100 flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  localStorage.removeItem('oppo_a53_pin_history');
                  setHistory([]);
                }}
                disabled={history.length === 0}
                className="flex-1 py-2 rounded-xl border border-neutral-200 text-xs text-rose-600 font-medium hover:bg-rose-50 disabled:opacity-40"
              >
                Clear History
              </button>
              <button
                type="button"
                onClick={() => setShowHistoryModal(false)}
                className="flex-1 py-2 rounded-xl bg-black text-white text-xs font-medium hover:bg-neutral-800"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
