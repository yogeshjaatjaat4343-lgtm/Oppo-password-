export type ScreenMode = 'light_lock' | 'dark_lock' | 'settings_verify';

export interface PasswordHistoryEntry {
  id: string;
  pin: string;
  timestamp: string; // ISO string
  formattedTime: string;
  mode: ScreenMode;
  modeLabel: string;
  status: 'submitted' | 'unlocked' | 'failed' | 'cleared';
  durationSeconds: number;
  ipPlaceholder?: string;
  notes?: string;
}

export interface LockScreenConfig {
  targetPin: string;
  soundEnabled: boolean;
  vibrateEnabled: boolean;
  autoSubmitOn6Digits: boolean;
  showPhoneFrame: boolean;
  selectedMode: ScreenMode;
}
