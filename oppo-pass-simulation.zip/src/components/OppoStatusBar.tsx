import React, { useState, useEffect } from 'react';
import { Wifi } from 'lucide-react';

interface OppoStatusBarProps {
  darkTheme?: boolean;
}

export const OppoStatusBar: React.FC<OppoStatusBarProps> = ({ darkTheme = false }) => {
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      setTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const textColor = darkTheme ? 'text-white' : 'text-neutral-900';

  return (
    <div
      id="oppo-status-bar"
      className={`relative w-full px-5 pt-3 pb-1 flex items-center justify-between text-xs font-medium select-none z-30 ${textColor}`}
    >
      {/* Left side: Oppo A53 punch-hole camera + real-time clock */}
      <div className="flex items-center gap-2.5">
        {/* Punch-hole camera simulator (Top Left like authentic Oppo A53) */}
        <div
          id="oppo-punch-hole-camera"
          className="relative w-3.5 h-3.5 rounded-full bg-black ring-1 ring-neutral-800 shadow-inner flex items-center justify-center -ml-1"
          title="Oppo A53 Front Punch-Hole Camera (16 MP)"
        >
          {/* Subtle camera lens reflection glint */}
          <div className="w-1.5 h-1.5 rounded-full bg-neutral-950 border border-neutral-700/60 flex items-center justify-center">
            <div className="w-0.5 h-0.5 rounded-full bg-blue-900/60"></div>
          </div>
        </div>

        {/* Live clock matching Oppo font style */}
        <span className="font-semibold tracking-tight text-[13px] ml-0.5 font-sans">
          {time || '18:58'}
        </span>

        {/* Subtle notification icon (ColorOS style VoLTE or small badge) */}
        <span className="text-[10px] px-1 py-0.2 rounded border border-current opacity-60 scale-90 font-mono">
          VoLTE
        </span>
      </div>

      {/* Right side: Network signals, Wi-Fi, and Battery */}
      <div className="flex items-center gap-1.5">
        {/* Cellular signal bars */}
        <div className="flex items-end gap-0.5 h-2.5">
          <span className="w-0.5 h-1 bg-current rounded-xs opacity-90"></span>
          <span className="w-0.5 h-1.5 bg-current rounded-xs opacity-90"></span>
          <span className="w-0.5 h-2 bg-current rounded-xs opacity-90"></span>
          <span className="w-0.5 h-2.5 bg-current rounded-xs opacity-90"></span>
        </div>

        {/* Wi-Fi Icon */}
        <Wifi className="w-3.5 h-3.5 stroke-[2.2]" />

        {/* Battery with percentage */}
        <div className="flex items-center gap-1 ml-0.5">
          <span className="text-[11px] font-medium font-sans">85%</span>
          <div className="relative w-5 h-2.5 rounded-xs border border-current p-0.5 flex items-center">
            <div className="h-full w-[85%] bg-current rounded-xs"></div>
            {/* Battery terminal pip */}
            <span className="absolute -right-0.5 top-0.5 bottom-0.5 w-0.5 bg-current rounded-r-xs"></span>
          </div>
        </div>
      </div>
    </div>
  );
};
