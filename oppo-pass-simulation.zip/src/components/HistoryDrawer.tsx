import React, { useState } from 'react';
import { PasswordHistoryEntry, LockScreenConfig } from '../types';
import {
  exportHistoryAsCSV,
  exportHistoryAsJSON,
  clearAllHistory,
  deleteHistoryItem,
} from '../utils/storage';
import {
  X,
  Trash2,
  Download,
  Copy,
  Check,
  Search,
  KeyRound,
  ShieldCheck,
  ShieldAlert,
  Sliders,
  Volume2,
  VolumeX,
  Vibrate,
  Clock,
} from 'lucide-react';

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  history: PasswordHistoryEntry[];
  onHistoryUpdate: (newHistory: PasswordHistoryEntry[]) => void;
  config: LockScreenConfig;
  onConfigUpdate: (newConfig: LockScreenConfig) => void;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  isOpen,
  onClose,
  history,
  onHistoryUpdate,
  config,
  onConfigUpdate,
}) => {
  const [activeTab, setActiveTab] = useState<'history' | 'settings'>('history');
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);

  if (!isOpen) return null;

  const handleCopyPin = (pin: string, id: string) => {
    navigator.clipboard?.writeText(pin);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDelete = (id: string) => {
    const updated = deleteHistoryItem(id);
    onHistoryUpdate(updated);
  };

  const handleClearAll = () => {
    clearAllHistory();
    onHistoryUpdate([]);
    setConfirmClear(false);
  };

  const filteredHistory = history.filter((item) => {
    if (!searchTerm) return true;
    return (
      item.pin.includes(searchTerm) ||
      item.formattedTime.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.modeLabel.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.status.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const totalAttempts = history.length;
  const unlockedCount = history.filter((h) => h.status === 'unlocked').length;
  const failedCount = history.filter((h) => h.status === 'failed').length;
  const uniquePins = new Set(history.map((h) => h.pin)).size;

  return (
    <div
      id="history-drawer-overlay"
      className="fixed inset-0 z-50 flex items-center justify-end bg-black/50 backdrop-blur-xs transition-opacity"
    >
      <div
        id="history-drawer-panel"
        className="w-full max-w-md h-full bg-white dark:bg-neutral-900 shadow-2xl flex flex-col justify-between text-neutral-900 dark:text-white border-l border-neutral-200 dark:border-neutral-800 animate-in slide-in-from-right duration-200"
      >
        {/* Header */}
        <div className="p-4 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <KeyRound className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-semibold">Password Entry History</h2>
                <p className="text-xs text-neutral-500 dark:text-neutral-400">
                  All entered PINs are automatically recorded
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-colors"
              aria-label="Close drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 mt-4 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-lg text-xs font-medium">
            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`flex-1 py-1.5 rounded-md transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'history'
                  ? 'bg-white dark:bg-neutral-700 text-neutral-900 dark:text-white shadow-xs'
                  : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-300'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              History ({totalAttempts})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('settings')}
              className={`flex-1 py-1.5 rounded-md transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'settings'
                  ? 'bg-white dark:bg-neutral-700 text-neutral-900 dark:text-white shadow-xs'
                  : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-300'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              Simulator Settings
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {activeTab === 'history' ? (
            <>
              {/* Summary Metrics */}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="p-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/60 dark:border-neutral-800">
                  <span className="block text-xl font-bold text-neutral-800 dark:text-neutral-100">
                    {totalAttempts}
                  </span>
                  <span className="text-[11px] text-neutral-500">Total Entries</span>
                </div>
                <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-800/40">
                  <span className="block text-xl font-bold text-emerald-600 dark:text-emerald-400">
                    {unlockedCount}
                  </span>
                  <span className="text-[11px] text-emerald-700 dark:text-emerald-300">Unlocked</span>
                </div>
                <div className="p-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/60 dark:border-neutral-800">
                  <span className="block text-xl font-bold text-neutral-800 dark:text-neutral-100">
                    {uniquePins}
                  </span>
                  <span className="text-[11px] text-neutral-500">Unique PINs</span>
                </div>
              </div>

              {/* Search & Actions Bar */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                  <input
                    type="text"
                    placeholder="Search by PIN or time..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 text-xs bg-neutral-100 dark:bg-neutral-800 rounded-lg border border-transparent focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => exportHistoryAsCSV(history)}
                  title="Export to CSV"
                  disabled={history.length === 0}
                  className="p-2 rounded-lg bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-600 dark:text-neutral-300 disabled:opacity-40 transition-colors"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>

              {/* List of Entries */}
              {filteredHistory.length === 0 ? (
                <div className="text-center py-12 px-4 border border-dashed border-neutral-300 dark:border-neutral-800 rounded-2xl">
                  <KeyRound className="w-10 h-10 mx-auto text-neutral-400 mb-2 stroke-1" />
                  <p className="text-sm font-medium text-neutral-600 dark:text-neutral-300">
                    No passwords recorded yet
                  </p>
                  <p className="text-xs text-neutral-400 mt-1 max-w-xs mx-auto">
                    Type any PIN on the Oppo keypad or your computer keyboard and it will immediately appear here.
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {filteredHistory.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200/70 dark:border-neutral-700/60 flex items-center justify-between gap-3 group transition-all hover:border-emerald-500/40"
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                            item.status === 'unlocked'
                              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                              : item.status === 'failed'
                              ? 'bg-rose-500/10 text-rose-500'
                              : 'bg-blue-500/10 text-blue-500'
                          }`}
                        >
                          {item.status === 'unlocked' ? (
                            <ShieldCheck className="w-5 h-5" />
                          ) : (
                            <ShieldAlert className="w-5 h-5" />
                          )}
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-lg font-mono font-bold tracking-wider text-neutral-900 dark:text-white">
                              {item.pin}
                            </span>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                                item.status === 'unlocked'
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                  : item.status === 'failed'
                                  ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                  : 'bg-neutral-200 text-neutral-700 dark:bg-neutral-700 dark:text-neutral-300'
                              }`}
                            >
                              {item.status === 'unlocked'
                                ? 'Unlocked'
                                : item.status === 'failed'
                                ? 'Incorrect'
                                : 'Entered'}
                            </span>
                          </div>

                          <p className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-0.5">
                            {item.formattedTime} &middot; {item.modeLabel}
                          </p>
                          {item.durationSeconds > 0 && (
                            <span className="text-[10px] text-neutral-400">
                              Typed in {item.durationSeconds}s
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleCopyPin(item.pin, item.id)}
                          className="p-1.5 rounded-md hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-500 hover:text-neutral-800 dark:hover:text-white transition-colors"
                          title="Copy Password"
                        >
                          {copiedId === item.id ? (
                            <Check className="w-4 h-4 text-emerald-500" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(item.id)}
                          className="p-1.5 rounded-md hover:bg-rose-100 dark:hover:bg-rose-900/30 text-neutral-400 hover:text-rose-600 transition-colors"
                          title="Delete entry"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          ) : (
            /* Settings Tab */
            <div className="space-y-4 text-xs">
              <div className="p-3.5 rounded-xl bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 space-y-3">
                <label className="block font-semibold text-neutral-800 dark:text-neutral-200">
                  Target Unlock PIN
                </label>
                <p className="text-neutral-500 dark:text-neutral-400 -mt-1">
                  Default is <code>123456</code>. When this PIN is entered, the screen displays success and unlocks to the Oppo Home Screen.
                </p>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    maxLength={6}
                    value={config.targetPin}
                    onChange={(e) => {
                      const clean = e.target.value.replace(/\D/g, '').slice(0, 6);
                      onConfigUpdate({ ...config, targetPin: clean });
                    }}
                    placeholder="e.g. 123456"
                    className="w-36 px-3 py-1.5 font-mono text-sm tracking-widest bg-white dark:bg-neutral-900 rounded-lg border border-neutral-300 dark:border-neutral-700 focus:outline-none focus:border-emerald-500"
                  />
                  <span className="text-[11px] text-neutral-400">Must be 6 digits</span>
                </div>
              </div>

              {/* Sound & Haptic toggles */}
              <div className="p-3.5 rounded-xl bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 space-y-3">
                <span className="block font-semibold text-neutral-800 dark:text-neutral-200">
                  Feedback & Sounds
                </span>

                <div className="flex items-center justify-between py-1 border-b border-neutral-200/60 dark:border-neutral-700/60">
                  <div className="flex items-center gap-2">
                    {config.soundEnabled ? (
                      <Volume2 className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <VolumeX className="w-4 h-4 text-neutral-400" />
                    )}
                    <div>
                      <p className="font-medium">Keypad Tap Sounds</p>
                      <p className="text-[11px] text-neutral-400">ColorOS mechanical tick audio</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={config.soundEnabled}
                    onChange={(e) => onConfigUpdate({ ...config, soundEnabled: e.target.checked })}
                    className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between py-1 border-b border-neutral-200/60 dark:border-neutral-700/60">
                  <div className="flex items-center gap-2">
                    <Vibrate className="w-4 h-4 text-emerald-500" />
                    <div>
                      <p className="font-medium">Haptic Vibration</p>
                      <p className="text-[11px] text-neutral-400">Mobile device vibration on taps</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={config.vibrateEnabled}
                    onChange={(e) => onConfigUpdate({ ...config, vibrateEnabled: e.target.checked })}
                    className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between py-1">
                  <div>
                    <p className="font-medium">Auto-Submit on 6 Digits</p>
                    <p className="text-[11px] text-neutral-400">Checks PIN as soon as 6th digit is typed</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={config.autoSubmitOn6Digits}
                    onChange={(e) =>
                      onConfigUpdate({ ...config, autoSubmitOn6Digits: e.target.checked })
                    }
                    className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
                  />
                </div>
              </div>

              {/* Export all options */}
              <div className="p-3.5 rounded-xl bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 space-y-2">
                <span className="block font-semibold text-neutral-800 dark:text-neutral-200">
                  Export Data
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => exportHistoryAsCSV(history)}
                    disabled={history.length === 0}
                    className="flex-1 py-2 px-3 rounded-lg bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 font-medium hover:bg-neutral-50 dark:hover:bg-neutral-800 disabled:opacity-40 transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Export CSV
                  </button>
                  <button
                    type="button"
                    onClick={() => exportHistoryAsJSON(history)}
                    disabled={history.length === 0}
                    className="flex-1 py-2 px-3 rounded-lg bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 font-medium hover:bg-neutral-50 dark:hover:bg-neutral-800 disabled:opacity-40 transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Export JSON
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        {activeTab === 'history' && history.length > 0 && (
          <div className="p-4 border-t border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900/90">
            {confirmClear ? (
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-rose-600 dark:text-rose-400 font-medium">
                  Delete all {history.length} records?
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setConfirmClear(false)}
                    className="px-3 py-1.5 text-xs rounded-lg border border-neutral-300 dark:border-neutral-700 font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleClearAll}
                    className="px-3 py-1.5 text-xs rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-medium shadow-xs"
                  >
                    Yes, Clear All
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmClear(true)}
                className="w-full py-2 px-3 rounded-lg text-xs font-medium text-rose-600 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center justify-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                Clear All History
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
