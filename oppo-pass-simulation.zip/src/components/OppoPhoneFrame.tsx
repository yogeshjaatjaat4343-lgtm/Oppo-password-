import React from 'react';

interface OppoPhoneFrameProps {
  children: React.ReactNode;
  showFrame: boolean;
  onPowerButton?: () => void;
  onVolumeButton?: () => void;
}

export const OppoPhoneFrame: React.FC<OppoPhoneFrameProps> = ({
  children,
  showFrame,
  onPowerButton,
  onVolumeButton,
}) => {
  if (!showFrame) {
    return (
      <div className="w-full max-w-sm h-screen sm:h-[840px] sm:max-h-[92vh] sm:rounded-3xl shadow-2xl overflow-hidden bg-neutral-900 mx-auto flex flex-col relative">
        {children}
      </div>
    );
  }

  return (
    <div
      id="oppo-a53-chassis"
      className="relative mx-auto my-auto select-none transition-all duration-300"
    >
      {/* Physical Hardware Buttons on Chassis */}
      {/* Left side: Volume Rocker */}
      <div className="absolute -left-1.5 top-28 flex flex-col gap-3 z-0">
        <button
          type="button"
          onClick={onVolumeButton}
          title="Volume Up"
          className="w-1.5 h-10 bg-neutral-700 hover:bg-neutral-600 rounded-l-xs cursor-pointer shadow-xs active:scale-95"
          aria-label="Volume Up"
        />
        <button
          type="button"
          onClick={onVolumeButton}
          title="Volume Down"
          className="w-1.5 h-10 bg-neutral-700 hover:bg-neutral-600 rounded-l-xs cursor-pointer shadow-xs active:scale-95"
          aria-label="Volume Down"
        />
      </div>

      {/* Right side: Power Button (with signature green line or accent on Oppo) */}
      <div className="absolute -right-1.5 top-32 z-0">
        <button
          type="button"
          onClick={onPowerButton}
          title="Power / Lock Button"
          className="w-1.5 h-14 bg-neutral-700 hover:bg-neutral-600 rounded-r-xs cursor-pointer shadow-xs active:scale-95 flex items-center justify-center"
          aria-label="Power button"
        >
          <span className="w-0.5 h-4 bg-emerald-500 rounded-full"></span>
        </button>
      </div>

      {/* Outer Phone Bezel (Metallic Moonlight Black / Fairy White rim of Oppo A53) */}
      <div className="relative w-[345px] sm:w-[380px] h-[720px] sm:h-[800px] p-3 rounded-[44px] bg-gradient-to-b from-neutral-800 via-neutral-900 to-neutral-950 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7),0_0_0_1px_rgba(255,255,255,0.1)] ring-1 ring-black flex flex-col">
        {/* Top earpiece speaker grill */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-16 h-1 bg-neutral-800 rounded-full z-20"></div>

        {/* Inner Screen Surface */}
        <div className="relative w-full h-full rounded-[34px] overflow-hidden bg-white dark:bg-black flex flex-col shadow-inner">
          {children}
        </div>
      </div>
    </div>
  );
};
