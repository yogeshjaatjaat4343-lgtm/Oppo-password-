import React from 'react';

interface OppoNavigationBarProps {
  darkTheme?: boolean;
  onBack?: () => void;
  onHome?: () => void;
  onRecents?: () => void;
}

export const OppoNavigationBar: React.FC<OppoNavigationBarProps> = ({
  darkTheme = false,
  onBack,
  onHome,
  onRecents,
}) => {
  const iconColor = darkTheme ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-neutral-900';

  return (
    <div
      id="oppo-nav-bar"
      className="w-full h-11 flex items-center justify-around px-8 select-none z-20 pb-1"
    >
      {/* Recents Button: ||| (Oppo ColorOS style) */}
      <button
        type="button"
        id="oppo-nav-recents"
        onClick={onRecents}
        aria-label="Recent apps"
        className={`p-2 transition-transform active:scale-90 ${iconColor}`}
      >
        <div className="flex items-center gap-1">
          <span className="w-0.5 h-3.5 bg-current rounded-full"></span>
          <span className="w-0.5 h-3.5 bg-current rounded-full"></span>
          <span className="w-0.5 h-3.5 bg-current rounded-full"></span>
        </div>
      </button>

      {/* Home Button: soft rounded square or circle */}
      <button
        type="button"
        id="oppo-nav-home"
        onClick={onHome}
        aria-label="Home"
        className={`p-2 transition-transform active:scale-90 ${iconColor}`}
      >
        <div className="w-3.5 h-3.5 rounded-sm border-[1.75px] border-current"></div>
      </button>

      {/* Back Button: < triangle or chevron */}
      <button
        type="button"
        id="oppo-nav-back"
        onClick={onBack}
        aria-label="Back"
        className={`p-2 transition-transform active:scale-90 ${iconColor}`}
      >
        <svg
          className="w-3.5 h-3.5"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="15 18 9 12 15 6"></polyline>
        </svg>
      </button>
    </div>
  );
};
