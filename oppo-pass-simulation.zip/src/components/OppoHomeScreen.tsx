import React from 'react';
import { OppoStatusBar } from './OppoStatusBar';
import { OppoNavigationBar } from './OppoNavigationBar';
import {
  Phone,
  MessageSquare,
  Camera,
  Compass,
  Settings,
  Image as ImageIcon,
  Folder,
  Music,
  Lock,
} from 'lucide-react';

interface OppoHomeScreenProps {
  onLock: () => void;
  unlockedPin: string;
}

export const OppoHomeScreen: React.FC<OppoHomeScreenProps> = ({ onLock, unlockedPin }) => {
  const now = new Date();
  const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  const dateString = now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });

  const appIcons = [
    { label: 'Photos', icon: ImageIcon, color: 'bg-rose-500' },
    { label: 'Settings', icon: Settings, color: 'bg-slate-700' },
    { label: 'File Manager', icon: Folder, color: 'bg-amber-500' },
    { label: 'Music', icon: Music, color: 'bg-orange-500' },
  ];

  const dockIcons = [
    { label: 'Phone', icon: Phone, color: 'bg-emerald-500' },
    { label: 'Messages', icon: MessageSquare, color: 'bg-blue-500' },
    { label: 'Browser', icon: Compass, color: 'bg-cyan-600' },
    { label: 'Camera', icon: Camera, color: 'bg-indigo-600' },
  ];

  return (
    <div
      id="oppo-home-screen"
      className="relative w-full h-full flex flex-col justify-between select-none overflow-hidden bg-cover bg-center text-white"
      style={{
        background: 'linear-gradient(145deg, #1e3c72 0%, #2a5298 50%, #172554 100%)',
      }}
    >
      {/* Background abstract aesthetic wave */}
      <div className="absolute inset-0 opacity-30 pointer-events-none">
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full">
          <path d="M0,30 C30,60 70,10 100,40 L100,100 L0,100 Z" fill="rgba(56, 189, 248, 0.4)" />
          <path d="M0,60 C40,40 60,80 100,50 L100,100 L0,100 Z" fill="rgba(168, 85, 247, 0.2)" />
        </svg>
      </div>

      <div className="relative z-10">
        <OppoStatusBar darkTheme={true} />

        {/* Lock notification toast */}
        <div className="mx-4 mt-3 p-3 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10 flex items-center justify-between text-xs animate-in fade-in slide-in-from-top-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <div>
              <p className="font-medium text-white">Device Unlocked</p>
              <p className="text-[11px] text-neutral-300">PIN: {unlockedPin} &middot; Saved in History</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onLock}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white font-medium text-[11px] transition-colors"
          >
            <Lock className="w-3.5 h-3.5" />
            Lock
          </button>
        </div>

        {/* Oppo ColorOS digital clock widget */}
        <div className="px-7 pt-10 pb-4">
          <h1 className="text-6xl font-light tracking-tight text-white/95">{timeString}</h1>
          <div className="flex items-center gap-2 mt-1 text-sm text-white/80 font-normal">
            <span>{dateString}</span>
            <span>&middot;</span>
            <span>28&deg;C Sunny</span>
          </div>
        </div>

        {/* App grid */}
        <div className="grid grid-cols-4 gap-y-6 gap-x-2 px-6 mt-8">
          {appIcons.map((app) => {
            const Icon = app.icon;
            return (
              <div key={app.label} className="flex flex-col items-center gap-1.5 cursor-pointer group">
                <div
                  className={`w-14 h-14 rounded-2xl ${app.color} flex items-center justify-center shadow-lg shadow-black/20 group-active:scale-95 transition-transform`}
                >
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <span className="text-[11px] text-white/90 drop-shadow-sm truncate max-w-[64px] text-center font-normal">
                  {app.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Dock and Navigation Bar */}
      <div className="relative z-10 w-full pb-2">
        {/* Dock Icons */}
        <div className="grid grid-cols-4 gap-2 px-6 py-4 mx-4 mb-2 rounded-3xl bg-white/10 backdrop-blur-md border border-white/10">
          {dockIcons.map((app) => {
            const Icon = app.icon;
            return (
              <div key={app.label} className="flex flex-col items-center gap-1 cursor-pointer">
                <div
                  className={`w-13 h-13 rounded-2xl ${app.color} flex items-center justify-center shadow-md active:scale-95 transition-transform`}
                >
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <span className="text-[10px] text-white/90 drop-shadow-sm">{app.label}</span>
              </div>
            );
          })}
        </div>

        <OppoNavigationBar darkTheme={true} onBack={onLock} onHome={onLock} onRecents={onLock} />
      </div>
    </div>
  );
};
