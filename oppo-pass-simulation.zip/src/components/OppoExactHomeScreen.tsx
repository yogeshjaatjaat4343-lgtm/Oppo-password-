import React, { useRef, useState, useEffect } from 'react';

interface OppoExactHomeScreenProps {
  onLock: () => void;
  unlockedPin?: string;
  customImage?: string;
  onSelectImage: (fileDataUrl: string) => void;
}

export const OppoExactHomeScreen: React.FC<OppoExactHomeScreenProps> = ({
  onLock,
  customImage,
  onSelectImage,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Zoom and Pan state for viewing screenshot
  const [scale, setScale] = useState<number>(1);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const isDraggingRef = useRef<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const initialTouchDistanceRef = useRef<number | null>(null);
  const initialScaleRef = useRef<number>(1);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          onSelectImage(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          onSelectImage(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Zoom helpers
  const handleZoomIn = () => {
    setScale((prev) => Math.min(prev + 0.5, 4));
  };

  const handleZoomOut = () => {
    setScale((prev) => {
      const next = Math.max(prev - 0.5, 1);
      if (next === 1) setPosition({ x: 0, y: 0 });
      return next;
    });
  };

  const handleResetZoom = () => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  };

  // Double click / double tap to toggle zoom
  const handleDoubleClick = () => {
    if (scale > 1.2) {
      handleResetZoom();
    } else {
      setScale(2);
    }
  };

  // Mouse wheel zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (e.deltaY < 0) {
      setScale((prev) => Math.min(prev + 0.25, 4));
    } else {
      setScale((prev) => {
        const next = Math.max(prev - 0.25, 1);
        if (next === 1) setPosition({ x: 0, y: 0 });
        return next;
      });
    }
  };

  // Mouse drag panning when zoomed
  const handleMouseDown = (e: React.MouseEvent) => {
    if (scale <= 1) return;
    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX - position.x, y: e.clientY - position.y };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || scale <= 1) return;
    setPosition({
      x: e.clientX - dragStartRef.current.x,
      y: e.clientY - dragStartRef.current.y,
    });
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  // Touch pinch-to-zoom & touch drag panning
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const touch1 = e.touches[0];
      const touch2 = e.touches[1];
      const dist = Math.hypot(touch1.clientX - touch2.clientX, touch1.clientY - touch2.clientY);
      initialTouchDistanceRef.current = dist;
      initialScaleRef.current = scale;
    } else if (e.touches.length === 1 && scale > 1) {
      isDraggingRef.current = true;
      const touch = e.touches[0];
      dragStartRef.current = { x: touch.clientX - position.x, y: touch.clientY - position.y };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && initialTouchDistanceRef.current !== null) {
      const touch1 = e.touches[0];
      const touch2 = e.touches[1];
      const currentDist = Math.hypot(touch1.clientX - touch2.clientX, touch1.clientY - touch2.clientY);
      const ratio = currentDist / initialTouchDistanceRef.current;
      const newScale = Math.min(Math.max(initialScaleRef.current * ratio, 1), 4);
      setScale(newScale);
      if (newScale === 1) {
        setPosition({ x: 0, y: 0 });
      }
    } else if (e.touches.length === 1 && isDraggingRef.current && scale > 1) {
      const touch = e.touches[0];
      setPosition({
        x: touch.clientX - dragStartRef.current.x,
        y: touch.clientY - dragStartRef.current.y,
      });
    }
  };

  const handleTouchEnd = () => {
    initialTouchDistanceRef.current = null;
    isDraggingRef.current = false;
  };

  // Reset zoom on unmount or when image changes
  useEffect(() => {
    handleResetZoom();
  }, [customImage]);

  // 1. IF SCREENSHOT IS LOADED: DIRECTLY DISPLAY IT WITH FULL ZOOM AND PAN PERMISSION
  if (customImage) {
    return (
      <div
        id="oppo-direct-screenshot-view"
        className="relative w-full h-full bg-black select-none overflow-hidden flex flex-col justify-between"
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Zoomable & Pannable Container */}
        <div
          className="absolute inset-0 w-full h-full flex items-center justify-center overflow-hidden cursor-grab active:cursor-grabbing"
          onDoubleClick={handleDoubleClick}
        >
          <img
            src={customImage}
            alt="Original Screenshot"
            style={{
              transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
              transformOrigin: 'center center',
              transition: isDraggingRef.current ? 'none' : 'transform 0.15s ease-out',
            }}
            className="w-full h-full object-cover select-none pointer-events-none"
          />
        </div>

        {/* Hidden file input for changing image if needed */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />

        {/* Floating Zoom Controls Bar (Easy 1-tap Zoom In / Out / Reset) */}
        <div className="relative z-40 w-full pt-8 px-4 flex items-center justify-between pointer-events-auto">
          {/* Zoom In/Out pills */}
          <div className="flex items-center gap-1.5 bg-black/60 backdrop-blur-md px-2 py-1 rounded-full border border-white/20 shadow-lg text-white">
            <button
              type="button"
              onClick={handleZoomIn}
              className="w-7 h-7 rounded-full flex items-center justify-center hover:bg-white/20 active:scale-90 text-base font-bold transition-all"
              title="Zoom In (+)"
            >
              +
            </button>
            <span className="text-[11px] font-mono px-1 font-medium select-none min-w-[32px] text-center">
              {Math.round(scale * 100)}%
            </span>
            <button
              type="button"
              onClick={handleZoomOut}
              disabled={scale <= 1}
              className="w-7 h-7 rounded-full flex items-center justify-center hover:bg-white/20 active:scale-90 text-base font-bold disabled:opacity-40 transition-all"
              title="Zoom Out (-)"
            >
              −
            </button>
            {scale > 1 && (
              <button
                type="button"
                onClick={handleResetZoom}
                className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-white/20 hover:bg-white/30 active:scale-90 transition-all ml-1"
                title="Reset Zoom"
              >
                Reset
              </button>
            )}
          </div>

          {/* Lock Phone Button */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="py-1 px-2.5 rounded-full bg-black/60 backdrop-blur-md text-white text-[11px] font-medium border border-white/20 active:scale-95 shadow-lg"
              title="स्क्रीनशॉट बदलें"
            >
              🔄
            </button>
            <button
              type="button"
              onClick={onLock}
              className="py-1 px-3 rounded-full bg-black/60 backdrop-blur-md text-white text-[11px] font-medium border border-white/20 active:scale-95 shadow-lg flex items-center gap-1"
              title="Lock Phone"
            >
              <span>🔒</span> Lock
            </button>
          </div>
        </div>

        {/* Bottom Android Navigation bar overlay to lock phone */}
        <div
          id="screenshot-nav-bar"
          className="relative z-30 w-full h-12 flex items-center justify-around px-8 select-none pointer-events-auto"
        >
          <button
            type="button"
            onClick={onLock}
            className="w-10 h-10 flex items-center justify-center active:opacity-60"
            title="Lock Phone"
          >
            <div className="flex items-center gap-1 opacity-70 hover:opacity-100">
              <span className="w-0.5 h-3.5 bg-white rounded-full"></span>
              <span className="w-0.5 h-3.5 bg-white rounded-full"></span>
              <span className="w-0.5 h-3.5 bg-white rounded-full"></span>
            </div>
          </button>

          <button
            type="button"
            onClick={onLock}
            className="w-10 h-10 flex items-center justify-center active:opacity-60"
            title="Lock Phone"
          >
            <div className="w-3.5 h-3.5 rounded-xs border-[1.75px] border-white opacity-70 hover:opacity-100"></div>
          </button>

          <button
            type="button"
            onClick={onLock}
            className="w-10 h-10 flex items-center justify-center active:opacity-60"
            title="Lock Phone"
          >
            <svg
              className="w-3.5 h-3.5 stroke-white stroke-[2.5] fill-none opacity-70 hover:opacity-100"
              viewBox="0 0 24 24"
            >
              <polyline points="15 18 9 12 15 6"></polyline>
            </svg>
          </button>
        </div>
      </div>
    );
  }

  // 2. IF SCREENSHOT HAS NOT BEEN CHOSEN YET: PROMPT USER TO SELECT THEIR EXACT FILE
  return (
    <div
      id="oppo-screenshot-prompt-view"
      onDragOver={(e) => e.preventDefault()}
      onDrop={handleDrop}
      className="relative w-full h-full bg-[#0a0a0a] text-white select-none overflow-hidden flex flex-col justify-between p-6"
    >
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Top Header */}
      <div className="pt-8 text-center">
        <div className="w-16 h-16 mx-auto mb-4 rounded-3xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-3xl shadow-xl">
          📱
        </div>
        <h2 className="text-xl font-bold text-white tracking-tight">
          ओरिजिनल स्क्रीनशॉट लोड करें
        </h2>
        <p className="text-xs text-neutral-400 mt-1 max-w-[260px] mx-auto leading-relaxed">
          आपने जो स्क्रीनशॉट <span className="text-amber-400 font-mono">Screenshot_2026-09-12-20-06-04-95.jpg</span> भेजा है, उसे सीधे यहाँ सेलेक्ट करें ताकि वह बिना किसी बदलाव के 100% वैसा का वैसा खुले।
        </p>
      </div>

      {/* Upload Box */}
      <div
        onClick={() => fileInputRef.current?.click()}
        className="w-full border-2 border-dashed border-neutral-700 hover:border-emerald-500 bg-neutral-900/60 rounded-3xl p-6 flex flex-col items-center justify-center gap-3 cursor-pointer transition-colors text-center group"
      >
        <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
          📁
        </div>
        <div>
          <span className="text-sm font-semibold text-white block group-hover:text-emerald-400 transition-colors">
            स्क्रीनशॉट फ़ाइल चुनें
          </span>
          <span className="text-[11px] text-neutral-500 mt-0.5 block">
            यहाँ क्लिक करें या फ़ाइल ड्रैग करें (Ctrl+V से पेस्ट भी कर सकते हैं)
          </span>
        </div>
        <span className="text-[10px] text-emerald-400 font-medium px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
          एक बार चुनने पर यह हमेशा सेव रहेगा
        </span>
      </div>

      {/* Bottom Actions */}
      <div className="pb-4 flex flex-col gap-2">
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white text-sm font-semibold transition-all shadow-lg"
        >
          गैलरी से स्क्रीनशॉट चुनें
        </button>

        <button
          type="button"
          onClick={onLock}
          className="w-full py-2.5 rounded-xl text-neutral-400 hover:text-white text-xs font-medium transition-colors"
        >
          वापस लॉक स्क्रीन पर जाएँ (Lock Phone)
        </button>
      </div>
    </div>
  );
};
