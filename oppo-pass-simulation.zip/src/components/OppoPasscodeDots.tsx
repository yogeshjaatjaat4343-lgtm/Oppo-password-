import React from 'react';

interface OppoPasscodeDotsProps {
  length: number;
  maxLength?: number;
  darkTheme?: boolean;
  isError?: boolean;
}

export const OppoPasscodeDots: React.FC<OppoPasscodeDotsProps> = ({
  length,
  maxLength = 6,
  darkTheme = false,
  isError = false,
}) => {
  return (
    <div
      id="oppo-passcode-dots"
      className={`flex items-center justify-center gap-3.5 my-4 transition-transform ${
        isError ? 'animate-[shake_0.4s_ease-in-out]' : ''
      }`}
    >
      {Array.from({ length: maxLength }).map((_, index) => {
        const isFilled = index < length;

        let dotBg = '';
        if (isError) {
          dotBg = 'bg-rose-500 shadow-sm shadow-rose-500/30';
        } else if (darkTheme) {
          dotBg = isFilled ? 'bg-white scale-100' : 'bg-neutral-700/80';
        } else {
          dotBg = isFilled ? 'bg-neutral-800 scale-100' : 'bg-neutral-300/80';
        }

        return (
          <div
            key={`dot-${index}`}
            className={`w-3 h-3 rounded-full transition-all duration-150 ease-out transform ${dotBg} ${
              isFilled ? 'scale-105' : 'scale-90 opacity-70'
            }`}
          />
        );
      })}
    </div>
  );
};
