import React, { useState } from 'react';

interface OppoKeypadProps {
  onDigitPress: (digit: string) => void;
  onDeletePress: () => void;
  darkTheme?: boolean;
}

export const OppoKeypad: React.FC<OppoKeypadProps> = ({
  onDigitPress,
  onDeletePress,
  darkTheme = false,
}) => {
  const [activeKey, setActiveKey] = useState<string | null>(null);

  const handlePointerDown = (key: string) => {
    setActiveKey(key);
  };

  const handlePointerUp = () => {
    setActiveKey(null);
  };

  const textColor = darkTheme ? 'text-white' : 'text-neutral-900';
  const tapHighlight = darkTheme
    ? 'bg-neutral-800/80 active:bg-neutral-700'
    : 'bg-neutral-200/70 active:bg-neutral-300';

  const rows: Array<Array<{ type: 'digit' | 'delete' | 'empty'; val?: string }>> = [
    [
      { type: 'digit', val: '1' },
      { type: 'digit', val: '2' },
      { type: 'digit', val: '3' },
    ],
    [
      { type: 'digit', val: '4' },
      { type: 'digit', val: '5' },
      { type: 'digit', val: '6' },
    ],
    [
      { type: 'digit', val: '7' },
      { type: 'digit', val: '8' },
      { type: 'digit', val: '9' },
    ],
    [
      { type: 'empty' },
      { type: 'digit', val: '0' },
      { type: 'delete' },
    ],
  ];

  return (
    <div
      id="oppo-keypad"
      className="w-full max-w-[340px] mx-auto px-4 py-2 select-none"
      onPointerLeave={handlePointerUp}
      onPointerCancel={handlePointerUp}
    >
      <div className="grid grid-cols-3 gap-y-3 sm:gap-y-4 gap-x-2 place-items-center">
        {rows.flat().map((item, idx) => {
          if (item.type === 'empty') {
            return <div key={`empty-${idx}`} className="w-18 h-18" />;
          }

          if (item.type === 'delete') {
            const isPressed = activeKey === 'delete';
            return (
              <button
                key="key-delete"
                type="button"
                id="oppo-key-delete"
                aria-label="Backspace"
                onPointerDown={() => {
                  handlePointerDown('delete');
                  onDeletePress();
                }}
                onPointerUp={handlePointerUp}
                className={`w-18 h-18 sm:w-20 sm:h-20 flex items-center justify-center rounded-full transition-all duration-100 ${
                  isPressed ? tapHighlight : 'hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                {/* Authentic Android/ColorOS Backspace tag shape with 'x' inside */}
                <div
                  className={`relative flex items-center justify-center transition-transform ${
                    isPressed ? 'scale-90' : 'scale-100'
                  }`}
                >
                  <svg
                    className={`w-7 h-7 sm:w-8 sm:h-8 ${textColor}`}
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    {/* Tag badge with cut-out cross */}
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M22 6H8.5c-.7 0-1.37.31-1.82.85L1.5 12l5.18 5.15c.45.54 1.12.85 1.82.85H22c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-3.71 8.29a.996.996 0 11-1.41 1.41L14.5 13.32l-2.38 2.38a.996.996 0 11-1.41-1.41l2.38-2.38-2.38-2.38a.996.996 0 011.41-1.41l2.38 2.38 2.38-2.38a.996.996 0 011.41 1.41L15.91 11.9l2.38 2.39z"
                    />
                  </svg>
                </div>
              </button>
            );
          }

          const digit = item.val!;
          const isPressed = activeKey === digit;

          return (
            <button
              key={`key-${digit}`}
              type="button"
              id={`oppo-key-${digit}`}
              aria-label={`Digit ${digit}`}
              onPointerDown={() => {
                handlePointerDown(digit);
                onDigitPress(digit);
              }}
              onPointerUp={handlePointerUp}
              className={`w-18 h-18 sm:w-20 sm:h-20 rounded-full flex items-center justify-center relative transition-all duration-75 ${
                isPressed ? tapHighlight : 'hover:bg-black/5 dark:hover:bg-white/5'
              }`}
            >
              <span
                className={`text-[32px] sm:text-[36px] font-normal tracking-tight select-none font-sans leading-none ${textColor} transition-transform ${
                  isPressed ? 'scale-90' : 'scale-100'
                }`}
              >
                {digit}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
