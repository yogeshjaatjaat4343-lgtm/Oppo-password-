import React, { useState } from 'react';
import { ArrowLeft, Phone } from 'lucide-react';
import { OppoStatusBar } from './OppoStatusBar';

interface EmergencyScreenProps {
  onBack: () => void;
  onDigitPressSound?: () => void;
}

export const EmergencyScreen: React.FC<EmergencyScreenProps> = ({
  onBack,
  onDigitPressSound,
}) => {
  const [dialed, setDialed] = useState<string>('');

  const handleDigit = (d: string) => {
    onDigitPressSound?.();
    setDialed((prev) => (prev.length < 15 ? prev + d : prev));
  };

  const handleDelete = () => {
    onDigitPressSound?.();
    setDialed((prev) => prev.slice(0, -1));
  };

  return (
    <div
      id="oppo-emergency-screen"
      className="w-full h-full bg-black text-white flex flex-col justify-between select-none"
    >
      <div>
        <OppoStatusBar darkTheme={true} />

        {/* Top title and back button */}
        <div className="flex items-center justify-between px-6 pt-3 pb-4">
          <button
            type="button"
            id="emergency-back-btn"
            onClick={onBack}
            className="p-2 -ml-2 text-neutral-300 hover:text-white transition-transform active:scale-95"
            aria-label="Back to lock screen"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <span className="text-base font-medium text-neutral-200">Emergency call</span>
          <div className="w-8" />
        </div>

        {/* Dialed number display */}
        <div className="text-center px-4 py-6 min-h-[70px] flex items-center justify-center">
          <span className="text-3xl font-light tracking-wider text-white">
            {dialed || <span className="text-neutral-500 text-lg">Enter emergency number</span>}
          </span>
        </div>
      </div>

      {/* Dial pad */}
      <div className="w-full max-w-[320px] mx-auto px-4 pb-8">
        <div className="grid grid-cols-3 gap-y-4 place-items-center">
          {[
            { num: '1', sub: '' },
            { num: '2', sub: 'ABC' },
            { num: '3', sub: 'DEF' },
            { num: '4', sub: 'GHI' },
            { num: '5', sub: 'JKL' },
            { num: '6', sub: 'MNO' },
            { num: '7', sub: 'PQRS' },
            { num: '8', sub: 'TUV' },
            { num: '9', sub: 'WXYZ' },
            { num: '*', sub: '' },
            { num: '0', sub: '+' },
            { num: '#', sub: '' },
          ].map((item) => (
            <button
              key={item.num}
              type="button"
              onClick={() => handleDigit(item.num)}
              className="w-16 h-16 rounded-full bg-neutral-900 active:bg-neutral-800 flex flex-col items-center justify-center border border-neutral-800 transition-transform active:scale-95"
            >
              <span className="text-2xl font-light">{item.num}</span>
              {item.sub && <span className="text-[9px] text-neutral-400 -mt-0.5">{item.sub}</span>}
            </button>
          ))}
        </div>

        {/* Bottom call action row */}
        <div className="flex items-center justify-center gap-8 mt-6">
          <div className="w-12"></div>
          <button
            type="button"
            onClick={() => alert(`Calling emergency service: ${dialed || '112'}...`)}
            className="w-16 h-16 rounded-full bg-emerald-500 active:bg-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-white"
          >
            <Phone className="w-7 h-7" />
          </button>
          <div className="w-12 flex items-center justify-center">
            {dialed && (
              <button
                type="button"
                onClick={handleDelete}
                className="text-neutral-400 active:text-white p-2"
                aria-label="Delete"
              >
                ✕
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
