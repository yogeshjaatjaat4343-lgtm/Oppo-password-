import { PasswordHistoryEntry, ScreenMode, LockScreenConfig } from '../types';

const STORAGE_KEY_HISTORY = 'oppo_a53_password_history_v1';
const STORAGE_KEY_CONFIG = 'oppo_a53_config_v1';

export const DEFAULT_CONFIG: LockScreenConfig = {
  targetPin: '123456',
  soundEnabled: true,
  vibrateEnabled: true,
  autoSubmitOn6Digits: true,
  showPhoneFrame: true,
  selectedMode: 'light_lock',
};

export function getStoredConfig(): LockScreenConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CONFIG);
    if (raw) {
      return { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
    }
  } catch {
    // fallback
  }
  return DEFAULT_CONFIG;
}

export function saveStoredConfig(config: LockScreenConfig) {
  try {
    localStorage.setItem(STORAGE_KEY_CONFIG, JSON.stringify(config));
  } catch {
    // ignore
  }
}

export function getStoredHistory(): PasswordHistoryEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_HISTORY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch {
    // fallback
  }
  return [];
}

export function savePasswordAttempt(
  pin: string,
  mode: ScreenMode,
  status: 'submitted' | 'unlocked' | 'failed' | 'cleared',
  durationSeconds: number,
  notes?: string
): PasswordHistoryEntry {
  const now = new Date();
  const formattedTime = now.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const modeLabels: Record<ScreenMode, string> = {
    light_lock: 'Lock Screen (Light)',
    dark_lock: 'Lock Screen (Dark)',
    settings_verify: 'ColorOS Security Setup',
  };

  const newEntry: PasswordHistoryEntry = {
    id: `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    pin: pin || '(empty)',
    timestamp: now.toISOString(),
    formattedTime,
    mode,
    modeLabel: modeLabels[mode] || mode,
    status,
    durationSeconds: Number(durationSeconds.toFixed(1)),
    notes,
  };

  try {
    const current = getStoredHistory();
    const updated = [newEntry, ...current];
    // Keep up to 200 recent entries
    const truncated = updated.slice(0, 200);
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(truncated));
  } catch {
    // ignore storage quota error
  }

  return newEntry;
}

export function deleteHistoryItem(id: string): PasswordHistoryEntry[] {
  try {
    const current = getStoredHistory();
    const filtered = current.filter((item) => item.id !== id);
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(filtered));
    return filtered;
  } catch {
    return [];
  }
}

export function clearAllHistory(): void {
  try {
    localStorage.removeItem(STORAGE_KEY_HISTORY);
  } catch {
    // ignore
  }
}

export function exportHistoryAsJSON(history: PasswordHistoryEntry[]) {
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(history, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `oppo_a53_password_history_${Date.now()}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

export function exportHistoryAsCSV(history: PasswordHistoryEntry[]) {
  const headers = ['ID', 'Password/PIN', 'Timestamp', 'Formatted Time', 'Screen Mode', 'Status', 'Duration (s)', 'Notes'];
  const rows = history.map((item) => [
    item.id,
    `"${item.pin}"`,
    item.timestamp,
    `"${item.formattedTime}"`,
    `"${item.modeLabel}"`,
    item.status,
    item.durationSeconds,
    `"${item.notes || ''}"`,
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', url);
  downloadAnchor.setAttribute('download', `oppo_a53_password_history_${Date.now()}.csv`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}
